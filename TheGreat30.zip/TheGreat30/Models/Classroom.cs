namespace TheGreat30.Models
{
    public class Classroom
    {
        private string _id;
        private string _lesson;
        public string Id
        {
            get { return _id; }
        }
        public string Lesson
        {
            get { return _lesson; }
        }
        public Classroom(string id, string lesson)
        {
            _id = id; 
            _lesson = lesson;
        }
    }
}