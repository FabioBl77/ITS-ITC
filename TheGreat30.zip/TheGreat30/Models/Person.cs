﻿namespace TheGreat30.Models
{
    public class Person
    {
        private string _name;
        private string _surname;
        private string _cf;
        private string _email;

        public string Name
        {
            get { return _name; }
        }
        public string Surname
        {
            get { return _surname; }
        }
        public string Cf
        {
            get { return _cf; }
        }
        public string Email
        {
            get { return _email; }
        }


        public int Age { get; set; }

        public Person(string name, string surname, string cf, string email)
        {
            if (string.IsNullOrWhiteSpace(name))
            {
                //il costrutto throw permette di notificare un errore, deve essere catturato dal contesto chiamante
                //tramite il costrutto try-catch
                throw
                    new ArgumentException(
                        "The name cannot be null or empty or contains only white space",
                    nameof(name));
            }
            _name = name;

            if (string.IsNullOrWhiteSpace(surname))
            {
                //il costrutto throw permette di notificare un errore, deve essere catturato dal contesto chiamante
                //tramite il costrutto try-catch
                throw
                    new ArgumentException(
                        "The name cannot be null or empty or contains only white space",
                    nameof(surname));
            }
            _surname = surname;

            if (string.IsNullOrWhiteSpace(cf))
            {
                //il costrutto throw permette di notificare un errore, deve essere catturato dal contesto chiamante
                //tramite il costrutto try-catch
                throw
                    new ArgumentException(
                        "The name cannot be null or empty or contains only white space",
                    nameof(cf));
            }
            _cf = cf;

            if (string.IsNullOrWhiteSpace(email))
            {
                //il costrutto throw permette di notificare un errore, deve essere catturato dal contesto chiamante
                //tramite il costrutto try-catch
                throw
                    new ArgumentException(
                        "The name cannot be null or empty or contains only white space",
                    nameof(email));
            }
            _email = email;
        }

        public override string ToString()
        {
            return $"Person: {Name} {Surname}, Cf: {Cf}, Email: {Email}";
        }
    }
}