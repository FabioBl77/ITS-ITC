﻿namespace TheGreat30.Models
{
    //inheritance is a relation of type is_a

    public class Student : Person
    {
        private string _sn;
        private string _faculty;

        public string Sn
        {
            get { return _sn; }
        }
        public string Faculty
        {
            get { return _faculty; }
        }
        public Student(string name, string surname, string cf, string email, string sn, string faculty)
            : base(name, surname, cf, email)
        {

            _sn = sn;
            _faculty = faculty;
        }


        public override string ToString()
        {
            return $"Student: {Name} {Surname}, Cf: {Cf}, Email: {Email}, Serial Number: {Sn}, Faculty: {Faculty}";
        }
    }
}