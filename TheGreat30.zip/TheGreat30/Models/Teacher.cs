﻿namespace TheGreat30.Models
{
    public class Teacher : Person
    {
        private string _subject;
        private int _salary;

        public string Subject
        {
            get { return _subject; }
        }
        public int Salary
        {
            get { return _salary; }
        }
        public Teacher(string name, string surname, string cf, string email, string subject, int salary)
            : base(name, surname, cf, email)
        {

            _subject = subject;
            _salary = salary;
        }


        public override string ToString()
        {
            return $"Teacher: {Name} {Surname}, Cf: {Cf}, Email: {Email}, Subject: {Subject}, Salary: {Salary} euro";
        }
    }
}