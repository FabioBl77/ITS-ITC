﻿using TheGreat30.Models;

//questo è un commento su singola linea
/*
    Questo è un commento
    su più linee
*/

//dichiarazione delle variabili con assegnamento di un valore di default

string fullname = string.Empty;
int age = 0;
string command = string.Empty;
string role = string.Empty;
string[] validSubjects = { "Italiano", "Inglese", "Matematica" };

var classroomA = new Classroom("A","Italiano");
var classroomB = new Classroom("B","Inglese");
var classroomC = new Classroom("C","Matematica");
/*List<Person> people = new List<Person>();*/ //dichiarazione di una lista di stringhe

List<Teacher> teacherList = new List<Teacher>();
List<Student> studentList = new List<Student>();

//questo è il corpo di Program
ReadCommand();
while (command != "exit")
{
    switch (command)
    {
        case "create":
            CreateCommand();
            break;

        case "list":
            ListCommand();
            break;

        default:
            UnkwonCommand();
            break;
    }
}
Console.WriteLine("Ciao, alla prossima!");

//quà finisce il corpo di Program

//definizioni di metodi che non ritornano nulla (void) e non prendono alcun parametro di ingresso
//void AskForName()
//{
//    Console.WriteLine("Ciao, come ti chiami?");

//    fullname = Console.ReadLine();
//}

void AskForRole()
{
    Console.WriteLine("Vuoi creare teacher o student?");

    role = Console.ReadLine();

    switch (role)
    {
        case "student":
            CreateStudent();
            break;

        case "teacher":
            CreateTeacher();
            break;

        default:
            UnkwonCommand();
            break;
    }
}

void CreateTeacher()
{
    Console.WriteLine("Scrivi il nome:");
    string inputName = Console.ReadLine();
    Console.WriteLine("Scrivi il cognome");
    string inputSurname = Console.ReadLine();
    Console.WriteLine("Scrivi il codice fiscale");
    string inputCf = Console.ReadLine();
    Console.WriteLine("Scrivi l'email");
    string inputEmail = Console.ReadLine();
    Console.WriteLine("Scrivi la materia che insegna: Italiano, Inglese, Matematica");
    string inputSubject = Console.ReadLine();
   
    while (!validSubjects.Contains(inputSubject))
    {
        Console.WriteLine("Materia non valida. Inserisci una tra Italiano, Inglese, Matematica:");
        inputSubject = Console.ReadLine();
    }
    Console.WriteLine("Scrivi lo stipendio");
    int inputSalary = int.Parse(Console.ReadLine());

    var newTeacher = new Teacher(inputName, inputSurname, inputCf, inputEmail, inputSubject, inputSalary);

    teacherList.Add(newTeacher);
}

void CreateStudent()
{
    Console.WriteLine("Scrivi il nome:");
    string inputName = Console.ReadLine();
    Console.WriteLine("Scrivi il cognome");
    string inputSurname = Console.ReadLine();
    Console.WriteLine("Scrivi il codice fiscale");
    string inputCf = Console.ReadLine();
    Console.WriteLine("Scrivi l'email");
    string inputEmail = Console.ReadLine();
    Console.WriteLine("Scrivi la matricola");
    string inputSn = Console.ReadLine();
    Console.WriteLine("Scrivi lo facoltà che studia: Italiano, Inglese Matematica");
    string inputFaculty = Console.ReadLine();
  
    while (!validSubjects.Contains(inputFaculty))
    {
        Console.WriteLine("Materia non valida. Inserisci una tra Italiano, Inglese, Matematica:");
        inputFaculty = Console.ReadLine();
    }
    var newStudent = new Student(inputName, inputSurname, inputCf, inputEmail, inputSn, inputFaculty);


    studentList.Add(newStudent);
}


void AskForAge()
{
    Console.WriteLine("Quanti anni hai?");
    string inputAge = Console.ReadLine();

    age = int.Parse(inputAge);  //questo metodo può lanciare un eccezione, deve essere catturato dal contesto chiamante tramite il costrutto try-catch
}

void PrintWellcomeMessage()
{
    string message = "Ciao, ";

    Console
        .WriteLine(message + fullname + " " + age);
}

//definizione di un metodo che non ritorna nulla (void) e prende un parametro di tipo string come parametro di ingresso
void PrintWarningMessage(string message)
{
    Console.ForegroundColor = ConsoleColor.Red;
    Console.WriteLine(message);
    Console.ResetColor();
    command = string.Empty;
}

void ReadCommand()
{
    Console.WriteLine("Cosa vuoi fare?");
    Console.WriteLine("create - per creare una persona");
    Console.WriteLine("list - per avere informazioni sulla composizione delle aule");
    Console.WriteLine("exit - per uscire dal programma");
    command = Console.ReadLine();
}

//void PrintList()
//{
//    if (people.Count == 0)
//    {
//        Console.WriteLine("Non ci sono persone in lista.");
//        return;
//    }

//    foreach (var person in people)
//    {
//        Console.WriteLine(person);
//    }
//}

void CreateCommand()
{
    try //il costrutto try cattura le eccezioni lanciate nel suo corpo
    {
        AskForRole();
        //AskForName();
        //var person = new Student(fullname);
        //AskForAge();
        //person.Age = age;
        //people.Add(person);
        //PrintWellcomeMessage();
        ReadCommand();
    }
    catch (ArgumentException ex)
    {
        PrintWarningMessage(ex.Message);
    }
    catch (FormatException ex)
    {
        PrintWarningMessage(ex.Message);
    }
}

void PrintClassroomA()
{
    Console.WriteLine($"In questa classe si studia {classroomA.Lesson}");
    Console.WriteLine("L'insegnante è:");
    foreach(Teacher teacher in teacherList)
    {
        if (teacher.Subject == classroomA.Lesson)
        {
            Console.WriteLine(teacher);
        }
    }
    Console.WriteLine("Gli studenti sono:");
    foreach (Student student in studentList)
    {
        if (student.Faculty == classroomA.Lesson)
        {
            Console.WriteLine(student);
        }
    }
}

void PrintClassroomB()
{
    Console.WriteLine($"In questa classe si studia {classroomB.Lesson}");
    Console.WriteLine("L'insegnante è:");
    foreach (Teacher teacher in teacherList)
    {
        if (teacher.Subject == classroomB.Lesson)
        {
            Console.WriteLine(teacher);
        }
    }
    Console.WriteLine("Gli studenti sono:");
    foreach (Student student in studentList)
    {
        if (student.Faculty == classroomB.Lesson)
        {
            Console.WriteLine(student);
        }
    }
}

void PrintClassroomC()
{

    //foreach(Teacher t in teacherList)
    //{
    //    Console.WriteLine(t);
    //}

    Console.WriteLine($"In questa classe si studia {classroomC.Lesson}");
    Console.WriteLine("L'insegnante è:");
    foreach (Teacher teacher in teacherList)
    {
        if (teacher.Subject == classroomC.Lesson)
        {
            Console.WriteLine(teacher);
        }
    }
    Console.WriteLine("Gli studenti sono:");
    foreach (Student student in studentList)
    {
        if (student.Faculty == classroomC.Lesson)
        {
            Console.WriteLine(student);
        }
    }
}

void InfoClassroom()
{
    Console.WriteLine("Di quale aula vuoi le informazioni: A, B, C");
    string selection = Console.ReadLine();
    switch (selection)
    {
        case "A":
            PrintClassroomA();
            break;

        case "B":
            PrintClassroomB();
            break;

        case "C":
            PrintClassroomC();
            break;

        default:
            UnkwonCommand();
            break;
    }
}

void ListCommand()
{
    //PrintList();
    InfoClassroom();
    ReadCommand();
}

void UnkwonCommand()
{
    PrintWarningMessage("non ho capito.");
    ReadCommand();
}