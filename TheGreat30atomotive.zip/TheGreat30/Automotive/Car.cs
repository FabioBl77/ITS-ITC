﻿using System.Security.Cryptography.X509Certificates;

namespace Automotive
{
    public class Car : Vehicle
    {
        public Car(string vin) : base(vin) 
        {
        }
    }

}
