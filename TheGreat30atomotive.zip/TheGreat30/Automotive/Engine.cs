﻿namespace Automotive
{
    public class Engine 
    {
         public string Type { get; set; }
         public string HorsePower { get; set; }
    }

}
