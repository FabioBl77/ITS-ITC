﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Automotive
{
    public interface IVINGenerator
    {
        string Generate();
    }
    public class VINGenerator : IVINGenerator
    {
        private List<string> _generatedVINs = new List<string>();
        public string Generate()
        {
            var vin = Guid.NewGuid().ToString();
            if (_generatedVINs.Contains(vin))
            {
                throw new Exception("VIN already exist");
            }
            _generatedVINs.Add(vin);
            return vin;

        }
    }
    internal class Factory
    {
        private VINGenerator _vinGenerator;
        private Queue<Vehicle> _productionLine = new Queue<Vehicle>();

        public Factory(VINGenerator vinGenerator)
        {
            _vinGenerator = vinGenerator;
        }
        public void CreateVehicle(string vehicleType) 
        {
            
            switch (vehicleType)
            {
                case "Car":

                    Create(new Car(_vinGenerator.Generate()));
                    break;
                case "Truck":
                    Create(new Truck(_vinGenerator.Generate()));
                    break;
                case "Motorbike":
                    Create(new Motorbike(_vinGenerator.Generate()));
                    break;
                default:
                    break;
            }
        }

        public void Create(Car car)
        {
            _productionLine.Enqueue(car);
        }

        public void Create(Truck truck)
        {
            _productionLine.Enqueue(truck);
        }

        public void Create(Motorbike motorbyke)
        {
            _productionLine.Enqueue(motorbyke);
        }
    }
}
