﻿namespace Automotive
{
    public class Motorbike : Vehicle
    {
        public Motorbike(string vin) : base(vin) 
        {
        }
    }

}
