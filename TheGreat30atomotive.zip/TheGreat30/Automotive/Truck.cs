﻿namespace Automotive
{
    public class Truck : Vehicle
    {
        public Truck(string vin) : base(vin) 
        {
        }
    }

}
