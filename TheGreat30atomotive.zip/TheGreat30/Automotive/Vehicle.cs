﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Automotive
{
    public abstract class Vehicle
    {
        public string VIN {  get; private set; }
        public DateTime CreateAt {  get; set; }
        public string Manufacture { get; set; }
        public string Model { get; set; }
        public string Plate { get; set; }
        public Engine Engine { get; set; }

        protected Vehicle(string vin)
        {
            VIN = vin;
        }

        
    }

}
