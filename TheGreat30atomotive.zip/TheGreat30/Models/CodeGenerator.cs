﻿namespace TheGreat30.Models
{
    /// <summary>
    /// Represents a code generator
    /// </summary>
    public class CodeGenerator
    {
        private static List<string> _ids = new List<string>();

        /// <summary>
        /// Generates a code
        /// </summary>
        /// <param name="prefix"></param>
        /// <returns></returns>
        /// <exception cref="InvalidOperationException"></exception>
        public static string GenerateCode(string prefix)
        {
            var id = $"{prefix}-{Guid.NewGuid()}";
            if (_ids.Contains(id))
            {
                throw new InvalidOperationException("The generated id is already present");
            }
            _ids.Add(id);
            return id;
        }
    }
}