﻿namespace TheGreat30.Models
{
    internal class Course
    {
        private List<Student> _students = new List<Student>();

        /// <summary>
        /// Gets the title of the course
        /// </summary>
        public string Title { get; private set; } = string.Empty;

        /// <summary>
        /// Gets the description of the course
        /// </summary>
        public string Description { get; private set; } = string.Empty;

        /// <summary>
        /// Gets the duration of the course in hours
        /// </summary>
        public int Duration { get; private set; }

        /// <summary>
        /// Gets the list of students enrolled in the course
        /// </summary>
        public IEnumerable<Student> Students => _students;

        /// <summary>
        /// Gets the instructor of the course
        /// </summary>
        public Teacher Instructor { get; private set; }

        /// <summary>
        /// Gets the start date of the course
        /// </summary>
        public DateOnly StartDate { get; private set; }

        /// <summary>
        /// Gets the end date of the course
        /// </summary>
        public DateOnly EndDate { get; private set; }

        public void UpdateTitle(string title)
        {
            if (string.IsNullOrWhiteSpace(title))
            {
                throw new ArgumentException("The title cannot be null or empty or contain only white space", nameof(title));
            }
            Title = title;
        }

        public void UpdateDescription(string description)
        {
            if (string.IsNullOrWhiteSpace(description))
            {
                throw new ArgumentException("The description cannot be null or empty or contain only white space", nameof(description));
            }
            Description = description;
        }

        public void UpdateDuration(int duration)
        {
            if (duration <= 0)
            {
                throw new ArgumentException("The duration must be greater than zero", nameof(duration));
            }
            Duration = duration;
        }

        public void UpdateInstructor(Teacher instructor)
        {
            Instructor = instructor ?? throw new ArgumentNullException(nameof(instructor), "The instructor cannot be null");
        }

        public void UpdateStartDate(DateOnly startDate)
        {
            if (startDate == DateOnly.MinValue)
            {
                throw new ArgumentException("The start date is not valid", nameof(startDate));
            }
            StartDate = startDate;
        }

        public void UpdateEndDate(DateOnly endDate)
        {
            if (endDate == DateOnly.MinValue)
            {
                throw new ArgumentException("The end date is not valid", nameof(endDate));
            }
            EndDate = endDate;
        }

        public void AddStudent(Student student)
        {
            if (student == null)
            {
                throw new ArgumentNullException(nameof(student), "The student cannot be null");
            }
            _students.Add(student);
        }

        public void RemoveStudent(Student student)
        {
            if (student == null)
            {
                throw new ArgumentNullException(nameof(student), "The student cannot be null");
            }
            _students.Remove(student);
        }

        public override string ToString()
            => $"Title: {Title}, Description: {Description}, Duration: {Duration} hours, " +
               $"Instructor: {Instructor?.Name} {Instructor?.Surname}, " +
               $"StartDate: {StartDate}, EndDate: {EndDate}, " +
               $"Students Enrolled: {_students.Count}";
    }
}