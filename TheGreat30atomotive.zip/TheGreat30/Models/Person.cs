﻿namespace TheGreat30.Models
{
    /// <summary>
    /// Represents a person
    /// </summary>
    public class Person
    {
        /// <summary>
        /// Gets the name of the person
        /// </summary>
        public string Name { get; private set; } = string.Empty;

        /// <summary>
        /// Gets the surname of the person
        /// </summary>
        public string Surname { get; private set; } = string.Empty;

        /// <summary>
        /// Gets the birth date of the person
        /// </summary>
        public DateOnly BirthDate { get; private set; }

        /// <summary>
        /// Gets the age of the person
        /// </summary>
        public int Age => DateTime.Now.Year - BirthDate.Year;

        public void UpdateBirthDate(DateOnly birthDate)
        {
            if (birthDate == DateOnly.MinValue)
            {
                throw new ArgumentException(message: "", paramName: nameof(birthDate));
            }
            BirthDate = birthDate;
        }
        public void UpdateBirthDate(string birthDate)
        {
            if(string.IsNullOrWhiteSpace(birthDate))
            {
                throw new ArgumentException(message: "The birth date cannot be null or empty or contains only white space",
                                            paramName: nameof(birthDate));
            }

            if(!DateOnly.TryParse(birthDate, out DateOnly date))
            {
                throw new ArgumentException(message: "The birth date is not in the correct format",
                                            paramName: nameof(birthDate));
            }
            UpdateBirthDate(date);
        }

      
        public void UpdateSurname(string surname)
        {
            if (string.IsNullOrWhiteSpace(surname))
            {
                throw new ArgumentException(message: "The surname cannot be null or empty or contains only white space",
                                            paramName: nameof(surname));
            }
            Surname = surname;
        }

        public void UpdateName(string name)
        {
            if (string.IsNullOrWhiteSpace(name))
            {
                throw new ArgumentException(message: "The name cannot be null or empty or contains only white space",
                                            paramName: nameof(name));
            }
            Name = name;
        }

        public override string ToString()
             => $"Name: {Name}, Surname: {Surname}, BirthDate: {BirthDate}, Age: {Age}";

    }
}