﻿namespace TheGreat30.Models
{
    public class SchoolStaff : Person
    {
        public string Code { get; private set; } = string.Empty;

        public SchoolStaff(string staffCode)
        {
            CheckCode(staffCode);
            UpdateCode(staffCode);
        }

        private void UpdateCode(string staffCode)
        {
            Code = staffCode;
        }

        protected virtual void CheckCode(string staffCode)
        {
            if (string.IsNullOrWhiteSpace(staffCode))
            {
                throw new ArgumentException(message: "The staff code cannot be null or empty or contains only white space",
                                            paramName: nameof(staffCode));
            }
        }
         
        public override string ToString()
        {
            return $"{base.ToString()}, Code: {Code}";
        }
    }
}