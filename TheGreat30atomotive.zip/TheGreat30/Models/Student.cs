﻿namespace TheGreat30.Models
{

    /// <summary>
    /// Represents a student
    /// </summary>
    public class Student : SchoolStaff
    {
        private const char _studentPrefixCode = 'S';

        public Student(string code)
            : base(code)
        {
        }

        /// <summary>
        /// Updates the code of the student
        /// </summary>
        /// <param name="code"></param>
        /// <exception cref="ArgumentException"></exception>
        protected override void CheckCode(string code)
        {
            base.CheckCode(code);
            if (!code.StartsWith(_studentPrefixCode))
            {
                throw new ArgumentException(message: $"The code must start with {_studentPrefixCode}",
                                            paramName: nameof(code));
            }
        }

    }
}