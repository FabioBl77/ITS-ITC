﻿namespace TheGreat30.Models
{
    public class Teacher : SchoolStaff
    {
        private const char _teacherPrefixCode = 'T';

        public string Code { get; private set; } = string.Empty;

        public Teacher(string code)
            : base(code)
        {
        }

        protected override void CheckCode(string code)
        {
            base.CheckCode(code);
            if (!code.StartsWith(_teacherPrefixCode))
            {
                Code = string.Empty;
                throw new ArgumentException(message: $"The code must start with {_teacherPrefixCode}",
                                            paramName: nameof(code));
            }
        }
    }
}