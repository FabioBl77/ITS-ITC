﻿    using TheGreat30.Models;
using TheGreat30.Services;

//questo è un commento su singola linea
/*
    Questo è un commento
    su più linee
*/

Ilogger logger = new ConsoleLogger();
string command = string.Empty;
List<Person> people = new List<Person>(); //dichiarazione di una lista di stringhe
List<Course> courses = new List<Course>();

//questo è il corpo di Program
ReadCommand();
while (command != "exit")
{
    switch (command)
    {
        case "create-student":
            CreateStudentCommand();
            break;
        case "create-teacher":
            CreateTeacherCommand();
            break;
        case "create-course":
            CreateCourseCommand();
            break;
        case "list-people":
            ListPeopleCommand();
            break;

        default:
            UnkwonCommand();
            break;
    }
    ReadCommand();
}
Console.WriteLine("Ciao, alla prossima!");

//quà finisce il corpo di Program
#region methods

//definizioni di metodi che non ritornano nulla (void) e non prendono alcun parametro di ingresso
string AskForName()
{
    Console.WriteLine("Ciao, qual'è il tuo nome?");

    return Console.ReadLine();
}

string AskForSurnName()
{
    Console.WriteLine("Ciao, qual'è il tuo cognome?");

    return Console.ReadLine();
}


string AskForBirthDate()
{
    Console.WriteLine("quando sei nato?");
    return Console.ReadLine();
}

void PrintWellcomeMessage(Person person)
{
    string message = "Ciao, ";

    Console
        .WriteLine(message + person.Name + " " + person.Age);
}

//definizione di un metodo che non ritorna nulla (void) e prende un parametro di tipo string come parametro di ingresso
void PrintWarningMessage(string message)
{
    Console.ForegroundColor = ConsoleColor.Red;
    Console.WriteLine(message);
    Console.ResetColor();
    command = string.Empty;
}

void ReadCommand()
{
    Console.WriteLine("Cosa vuoi fare?");
    command = Console.ReadLine();
}

void PrintPeopleList()
{
    if (people.Count == 0)
    {
        Console.WriteLine("Non ci sono persone in lista.");
        return;
    }

    foreach (var person in people)
    {
        Console.WriteLine(person);
    }
}

void CreateStudentCommand()
{
    try //il costrutto try cattura le eccezioni lanciate nel suo corpo
    {
        var student = new Student(CodeGenerator.GenerateCode("S"));
        CreatePersonCommand(student);
    }
    catch (InvalidOperationException ex)
    {
        PrintWarningMessage(ex.Message);
    }

}

void CreateTeacherCommand()
{
    try //il costrutto try cattura le eccezioni lanciate nel suo corpo
    {
        var teacher = new Teacher(CodeGenerator.GenerateCode("T"));
        CreatePersonCommand(teacher);
    }
    catch (InvalidOperationException ex)
    {
        PrintWarningMessage(ex.Message);
    }

}

void CreatePersonCommand(Person person)
{
    try //il costrutto try cattura le eccezioni lanciate nel suo corpo
    {
        person.UpdateName(AskForName());
        person.UpdateSurname(AskForSurnName());
        person.UpdateBirthDate(AskForBirthDate());
        people.Add(person);
        PrintWellcomeMessage(person);

    }
    catch (ArgumentException ex)
    {
        PrintWarningMessage(ex.Message);
    }
    catch (FormatException ex)
    {
        PrintWarningMessage(ex.Message);
    }
}

void CreateCourseCommand()
{
    try //il costrutto try cattura le eccezioni lanciate nel suo corpo
    {
        var course = new Course();
        course.UpdateTitle(AskForCourseTitle());
        course.UpdateDescription(AskForCourseDescription());
        course.UpdateDuration(AskForCourseDuration());
        course.UpdateStartDate(AskForCourseStartDate());
        course.UpdateEndDate(AskForCourseEndDate());
        courses.Add(course);
        PrintCourseWelcomeMessage(course);
    }
    catch (InvalidOperationException ex)
    {
        PrintWarningMessage(ex.Message);
    }
}

string AskForCourseTitle()
{
    Console.WriteLine("Qual è il nome del corso?");
    return Console.ReadLine();
}

string AskForCourseDescription()
{
    Console.WriteLine("Qual è la descrizione del corso?");
    return Console.ReadLine();
}

int AskForCourseDuration()
{
    Console.WriteLine("Qual è la durata del corso (in ore)?");
    return int.Parse(Console.ReadLine());
}

DateOnly AskForCourseStartDate()
{
    Console.WriteLine("Qual è la data di inizio del corso (yyyy-MM-dd)?");
    return DateOnly.Parse(Console.ReadLine());
}

DateOnly AskForCourseEndDate()
{
    Console.WriteLine("Qual è la data di fine del corso (yyyy-MM-dd)?");
    return DateOnly.Parse(Console.ReadLine());
}

void PrintCourseWelcomeMessage(Course course)
{
    string message = "Corso creato: ";
    Console.WriteLine(message + course.Title);
}

void ListPeopleCommand()
{
    PrintPeopleList();
}

void UnkwonCommand()
{
    PrintWarningMessage("non ho capito.");
    ReadCommand();
}
#endregion